import React,{useState} from 'react'
import { Link,useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/AuthContext'

export default function Register(){
 const {register}=useAuth(); const navigate=useNavigate()
 const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[nickname,setNickname]=useState('')
 const [error,setError]=useState(''),[message,setMessage]=useState(''),[busy,setBusy]=useState(false)
 const submit=async e=>{e.preventDefault();setError('');setMessage('');setBusy(true)
  try{const data=await register(email,password,{nickname}); if(!data.session)setMessage('Account created. Check your email to verify your account.'); else navigate('/')}
  catch(err){setError(err.message||'Unable to register.')} finally{setBusy(false)}
 }
 return <main className="min-h-screen flex items-center justify-center p-6"><form onSubmit={submit} className="w-full max-w-md space-y-4">
 <h1 className="text-3xl font-bold">Create account</h1>{error&&<p className="text-red-600">{error}</p>}{message&&<p>{message}</p>}
 <input className="w-full border rounded p-3" required placeholder="Nickname" value={nickname} onChange={e=>setNickname(e.target.value)}/>
 <input className="w-full border rounded p-3" required type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/>
 <input className="w-full border rounded p-3" required minLength={6} type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)}/>
 <button className="w-full rounded p-3 font-semibold" disabled={busy}>{busy?'Creating…':'Create account'}</button>
 <p>Already have an account? <Link to="/login">Sign in</Link></p>
 </form></main>
}
