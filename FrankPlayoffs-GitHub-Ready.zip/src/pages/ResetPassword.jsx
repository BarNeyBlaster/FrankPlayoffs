import React,{useState} from 'react'
import {useNavigate} from 'react-router-dom'
import {useAuth} from '../lib/AuthContext'
export default function ResetPassword(){
 const {updatePassword}=useAuth();const nav=useNavigate();const[p,setP]=useState('');const[c,setC]=useState('');const[e,setE]=useState('')
 const submit=async x=>{x.preventDefault();setE('');if(p.length<6)return setE('Password must be at least 6 characters.');if(p!==c)return setE('Passwords do not match.');try{await updatePassword(p);nav('/login')}catch(err){setE(err.message)}}
 return <main className="min-h-screen flex items-center justify-center p-6"><form onSubmit={submit} className="w-full max-w-md space-y-4"><h1 className="text-2xl font-bold">Choose a new password</h1>{e&&<p className="text-red-600">{e}</p>}<input className="w-full border rounded p-3" type="password" required placeholder="New password" value={p} onChange={e=>setP(e.target.value)}/><input className="w-full border rounded p-3" type="password" required placeholder="Confirm password" value={c} onChange={e=>setC(e.target.value)}/><button className="w-full rounded p-3">Update password</button></form></main>
}
