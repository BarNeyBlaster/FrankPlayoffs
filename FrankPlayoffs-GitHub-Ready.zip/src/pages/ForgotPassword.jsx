import React,{useState} from 'react'
import {Link} from 'react-router-dom'
import {useAuth} from '../lib/AuthContext'
export default function ForgotPassword(){
 const {resetPassword}=useAuth();const[email,setEmail]=useState('');const[status,setStatus]=useState('');const[error,setError]=useState('')
 const submit=async e=>{e.preventDefault();setStatus('');setError('');try{await resetPassword(email);setStatus('If an account exists for that email, a reset link has been sent.')}catch(err){setError(err.message)}}
 return <main className="min-h-screen flex items-center justify-center p-6"><form onSubmit={submit} className="w-full max-w-md space-y-4"><h1 className="text-2xl font-bold">Reset password</h1>{error&&<p className="text-red-600">{error}</p>}{status&&<p>{status}</p>}<input className="w-full border rounded p-3" type="email" required placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/><button className="w-full rounded p-3">Send reset link</button><Link to="/login">Back to sign in</Link></form></main>
}
