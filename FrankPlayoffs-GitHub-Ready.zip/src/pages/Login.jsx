import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../lib/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [error,setError]=useState('')
  const [busy,setBusy]=useState(false)

  const submit=async(e)=>{
    e.preventDefault(); setError(''); setBusy(true)
    try { await login(email,password); navigate('/') }
    catch(err){ setError(err.message || 'Unable to sign in.') }
    finally{ setBusy(false) }
  }
  return <main className="min-h-screen flex items-center justify-center p-6">
    <form onSubmit={submit} className="w-full max-w-md space-y-4">
      <h1 className="text-3xl font-bold">Frank Playoffs</h1>
      <h2 className="text-xl">Sign in</h2>
      {error && <p className="text-red-600">{error}</p>}
      <input className="w-full border rounded p-3" type="email" required placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="w-full border rounded p-3" type="password" required placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="w-full rounded p-3 font-semibold" disabled={busy}>{busy?'Signing in…':'Sign in'}</button>
      <p><Link to="/forgot-password">Forgot password?</Link></p>
      <p>Need an account? <Link to="/register">Register</Link></p>
    </form>
  </main>
}
