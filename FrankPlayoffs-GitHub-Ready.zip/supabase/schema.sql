-- Frank Playoffs: Supabase migration
-- Run this entire file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  nickname text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.predictions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  nickname text,
  season integer not null default 2026,
  afc_seeds jsonb not null default '[]'::jsonb,
  nfc_seeds jsonb not null default '[]'::jsonb,
  sb_champion text,
  sb_score_champ integer,
  sb_score_opp integer,
  bracket jsonb not null default '{}'::jsonb,
  submitted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.official_results (
  id uuid primary key default gen_random_uuid(),
  season integer not null unique,
  afc_seeds jsonb not null default '[]'::jsonb,
  nfc_seeds jsonb not null default '[]'::jsonb,
  sb_champion text,
  sb_champion_name text,
  sb_score_champ integer,
  sb_score_opp integer,
  bracket jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, nickname)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'nickname', split_part(coalesce(new.email, ''), '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.predictions enable row level security;
alter table public.official_results enable row level security;

drop policy if exists "profiles readable by signed in users" on public.profiles;
create policy "profiles readable by signed in users"
on public.profiles for select
to authenticated
using (true);

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "users read own prediction" on public.predictions;
create policy "users read own prediction"
on public.predictions for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "users create own prediction" on public.predictions;
create policy "users create own prediction"
on public.predictions for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "users update own prediction" on public.predictions;
create policy "users update own prediction"
on public.predictions for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "users delete own prediction" on public.predictions;
create policy "users delete own prediction"
on public.predictions for delete
to authenticated
using (auth.uid() = user_id);

drop policy if exists "signed in users read official results" on public.official_results;
create policy "signed in users read official results"
on public.official_results for select
to authenticated
using (true);

-- Admin writes are intentionally controlled through the profiles role.
drop policy if exists "admins write official results" on public.official_results;
create policy "admins write official results"
on public.official_results for all
to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists predictions_updated_at on public.predictions;
create trigger predictions_updated_at before update on public.predictions
for each row execute procedure public.set_updated_at();

drop trigger if exists official_results_updated_at on public.official_results;
create trigger official_results_updated_at before update on public.official_results
for each row execute procedure public.set_updated_at();

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;
